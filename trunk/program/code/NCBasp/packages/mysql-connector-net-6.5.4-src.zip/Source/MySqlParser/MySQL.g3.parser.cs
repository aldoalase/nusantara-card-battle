﻿namespace MySql.Parser
{
	partial class MySQLParser
	{
	}
}
