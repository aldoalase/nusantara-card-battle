﻿namespace MySql.Parser
{
	partial class MySQLLexer
	{
	}
}
